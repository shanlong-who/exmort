library(shiny)
if (.Platform$OS.type == "windows") Sys.setlocale("LC_CTYPE", "English_United States.utf8")
shiny::runApp(".", host = "127.0.0.1", port = 3880, launch.browser = FALSE)
