library(shiny)
library(DT)
library(openxlsx) # For reading Excel files
library(lubridate) # For date processing
library(dplyr) # For data operations
library(shinyjs) # For JavaScript-based UI enhancements
library(zoo) # 添加zoo包，用于na.locf函数

# 加载DT扩展
# 确保在全局.R或app.R中添加了以下代码
# options(DT.options = list(
#   language = list(url = '//cdn.datatables.net/plug-ins/1.10.11/i18n/Chinese.json')
# ))

source("modules/utils.R")
source("modules/cause_data.R", encoding = "UTF-8")

# 数据处理模块的UI部分
data_process_module_ui <- function(id) {
  ns <- NS(id)
  fluidPage(
    useShinyjs(), # 初始化shinyjs
    tags$head(
      tags$link(rel = "stylesheet", type = "text/css", href = "style.css"), # 可选
      tags$style(HTML("
        /* 表格下载按钮样式 */
        .dt-buttons {
          margin-bottom: 10px;
        }
        .download-btn {
          margin-bottom: 10px;
        }
      "))
    ),
    fluidRow(
      column(
        7,
        tabsetPanel(
          id = ns("datatabs"),
          tabPanel(
            "Upload Data",
            br(),
            wellPanel(
              p("This tool estimates weekly or monthly excess deaths in the Western Pacific Region."),
              p(
                strong("Expected deaths"), 
                "are estimated using user-selected statistical models, including ", 
                strong("Negative Binomial regression, Poisson regression, "), 
                "and ", 
                strong("ARIMA time series models"), 
                ", based on a user-defined baseline period (typically pre-incident)."
              ),
              p(
                class = "helper", icon("question-circle"),
                span("What format does the Excel file need?", style = "font-size:0.85em;"),
                br(), "Please upload a *.xls or *.xlsx file following the WHO standardized template."
              ),
              selectizeInput(ns("template_country"),
                label = "Download a template:",
                choices = c(
                  "Choose a template" = "",
                  "Australia (empty template)", "Philippines (empty template)", "French Polynesia (empty template)",
                  "Generic Monthly template", "Generic Weekly template", "Cause-specific monthly template",
                  "Australia (filled up to August 2020)", "Japan (filled up to August 2020)",
                  "Republic of Korea (filled up to August 2020)", "New Zealand (filled up to August 2020)",
                  "Philippines (filled up to August 2020)"
                )
              ),
              downloadButton(ns("download_templates"), "Download template"),
              br(), br(),
              selectInput(ns("filetype"),
                label = "Open a data set",
                choices = c(
                  "Excel spreadsheet (*.xls or *.xlsx)" = 1,
                  "Built-in example data" = 2
                )
              ),
              conditionalPanel(
                condition = paste0("input['", ns("filetype"), "'] == 1"),
                fileInput(ns("rawdatafile"), label = NULL, accept = c(".xls", ".xlsx")),
                uiOutput(ns("selectsheet")),
                uiOutput(ns("selecteventsheet")),
                actionButton(ns("loadEvents"), "Merge Mortality/Events Data"),
                # 上传数据的进度消息区域
                div(id = ns("progress_upload"), style = "color: blue; margin-top: 10px;")
              ),
              conditionalPanel(
                condition = paste0("input['", ns("filetype"), "'] == 2"),
                selectizeInput(ns("samplecountry"),
                  label = "Choose a country",
                  choices = c("Choose a dataset" = "", names(builtin_mortality_registry()))
                ),
                uiOutput(ns("selectbuiltinsheet")),
                uiOutput(ns("selectbuiltineventsheet")),
                actionButton(ns("loadBuiltinEvents"), "Merge Built-in Data"),
                # 内置数据的进度消息区域
                div(id = ns("progress_builtin"), style = "color: blue; margin-top: 10px;")
              ),
              uiOutput(ns("analysis_selection"))
            )
          ),
          tabPanel(
            "View Data",
            br(),
            p("The table shows the selected country and cause. Counts of zero are retained. Missing counts remain blank."),
            wellPanel(
              h4("Merged Data Table"),
              DTOutput(ns("ACM_table"), width = "100%"),
              # 添加下载按钮
              div(class = "download-btn",
                downloadButton(ns("downloadMergedData"), "Download selected series")
              ),
            ),
            wellPanel(
              h4("Raw Mortality Data"),
              DTOutput(ns("raw_mortality_table"), width = "100%"),
              # 添加下载按钮
              div(class = "download-btn",
                downloadButton(ns("downloadRawData"), "Download Full Data")
              )
            ),
            wellPanel(
              h4("Events Data"),
              DTOutput(ns("events_table"), width = "100%"),
              # 添加下载按钮
              div(class = "download-btn",
                downloadButton(ns("downloadEventsData"), "Download Full Data")
              )
            )
          )
        )
      ),
      column(
        4,
        tabsetPanel(
          tabPanel(
            "Data Summary", br(),
            verbatimTextOutput(ns("ACMsum"))
          )
        )
      )
    )
  )
}

# 数据处理模块的服务器部分
data_process_module_server <- function(id, rv) {
  moduleServer(id, function(input, output, session) {
    # 使用命名空间
    ns <- session$ns

    # 初始化本地响应式值
    data <- reactiveValues(
      acm_rawdata = NULL,
      acm_data = NULL,
      event_data = NULL,
      merged_data = NULL,
      data_description = NULL
    )

    selected_mortality <- reactive({
      req(data$merged_data)
      all_data <- data$merged_data
      countries <- unique(all_data$COUNTRY)
      country <- if (isTRUE(input$selected_country %in% countries)) input$selected_country else countries[1]
      country_data <- all_data[all_data$COUNTRY == country, , drop = FALSE]
      causes <- unique(country_data$CAUSE)
      preferred <- if ("Total" %in% causes) "Total" else causes[1]
      cause <- if (isTRUE(input$selected_cause %in% causes)) input$selected_cause else preferred
      country_data[country_data$CAUSE == cause, , drop = FALSE]
    })

    output$analysis_selection <- renderUI({
      req(data$merged_data)
      countries <- unique(data$merged_data$COUNTRY)
      country <- if (isTRUE(input$selected_country %in% countries)) input$selected_country else countries[1]
      causes <- unique(data$merged_data$CAUSE[data$merged_data$COUNTRY == country])
      selected <- if (isTRUE(input$selected_cause %in% causes)) input$selected_cause else causes[1]
      tagList(
        tags$hr(),
        selectInput(ns("selected_country"), "Country", countries, selected = country),
        selectizeInput(ns("selected_cause"), "Cause of death", causes, selected = selected),
        helpText("One country and one cause are analysed at a time. Changing either selection clears the previous results."),
        textOutput(ns("selection_coverage")),
        helpText(data$source_note)
      )
    })

    output$selection_coverage <- renderText({
      selected <- selected_mortality()
      baseline <- selected[selected$event_index == "0", , drop = FALSE]
      paste0(min(selected$YEAR), "-", max(selected$YEAR), "; ", nrow(selected), " periods; ",
             sum(is.na(selected$NO_DEATHS)), " missing counts; ", nrow(baseline), " baseline periods. ",
             if (nrow(baseline) < 24 && any(selected$CAUSE != "Total"))
               "Cause-specific modelling needs at least two complete baseline years. You can inspect and download these data." else "")
    })

    observeEvent(selected_mortality(), {
      clear_mortality_results(rv)
      rv$selected_country <- selected_mortality()$COUNTRY[1]
      rv$selected_cause <- selected_mortality()$CAUSE[1]
    }, ignoreNULL = TRUE)

    # Expose the selected series while retaining the complete imported dataset.
    observe({
      rv$acm_rawdata <- data$acm_rawdata
      rv$acm_data <- data$acm_data
      rv$event_data <- data$event_data
      rv$source_note <- data$source_note
      rv$merged_data <- if (is.null(data$merged_data)) NULL else selected_mortality()
      rv$data_description <- if (is.null(data$merged_data)) data$data_description else
        paste(data$data_description, "-", selected_mortality()$COUNTRY[1], "-", selected_mortality()$CAUSE[1])
    })

    # UI渲染
    output$selectsheet <- renderUI({
      req(input$rawdatafile)
      sheets <- mortality_sheet_names(input$rawdatafile$datapath)
      selected_sheet <- ifelse("National level" %in% sheets, "National level", sheets[1])
      selectInput(ns("sheetname"), "Select mortality data sheet", choices = sheets, selected = selected_sheet)
    })

    output$selecteventsheet <- renderUI({
      req(input$rawdatafile, input$sheetname)
      sheets <- readxl::excel_sheets(input$rawdatafile$datapath)
      event_sheets <- setdiff(sheets, input$sheetname)
      selected_event_sheets <- ifelse("events" %in% sheets, "events", event_sheets)
      selectInput(ns("eventsheetname"), "Select events data sheet", choices = selected_event_sheets)
    })

    output$selectbuiltinsheet <- renderUI({
      req(input$samplecountry)
      file_path <- builtin_mortality_path(input$samplecountry)
      if (file.exists(file_path)) {
        sheets <- mortality_sheet_names(file_path)
        selected_sheet <- ifelse("National level" %in% sheets, "National level", sheets[1])
        selectInput(ns("builtinsheetname"), "Select mortality data sheet", choices = sheets, selected = selected_sheet)
      }
    })

    output$selectbuiltineventsheet <- renderUI({
      req(input$samplecountry, input$builtinsheetname)
      file_path <- builtin_mortality_path(input$samplecountry)
      if (file.exists(file_path)) {
        sheets <- readxl::excel_sheets(file_path)
        event_sheets <- setdiff(sheets, input$builtinsheetname)
        selected_event_sheet <- ifelse("events" %in% event_sheets, "events", event_sheets)
        selectInput(ns("builtineventsheetname"), "Select events data sheet", choices = event_sheets, selected = selected_event_sheet)
      }
    })

    # 数据加载和合并（带进度显示）
    observeEvent(input$loadEvents, {
      req(input$rawdatafile, input$sheetname, input$eventsheetname)
      clear_mortality_results(rv)
      data$merged_data <- NULL

      # 显示进度消息
      shinyjs::html(ns("progress_upload"), "Processing data, please wait...")
      shinyjs::show(ns("progress_upload"))

      # 创建临时文件
      temp_file <- tempfile(pattern = "upload_", fileext = ".xlsx")
      file.copy(input$rawdatafile$datapath, temp_file, overwrite = TRUE)

      # 使用withProgress显示进度条
      withProgress(message = "Merging uploaded data...", value = 0, {
        tryCatch({
          # 读取死亡率数据
          incProgress(0.2, detail = "Reading mortality data...")
          raw_data <- openxlsx::read.xlsx(temp_file, sheet = input$sheetname, colNames = FALSE)
          data$acm_rawdata <- raw_data

          # 处理死亡率数据
          incProgress(0.4, detail = "Processing mortality data...")
          data$acm_data <- read_mortality_sheet(temp_file, input$sheetname)
          data$source_note <- mortality_source_note(temp_file)

          # 加载事件数据
          incProgress(0.6, detail = "Loading events data...")
          data$event_data <- loadEventsData(temp_file, input$eventsheetname)

          # 合并数据
          incProgress(0.8, detail = "Merging data...")
          if (!is.null(data$acm_data) && !is.null(data$event_data)) {
            data$merged_data <- mergeEventsData(data$acm_data, data$event_data)
            data$data_description <- paste("Uploaded data from", input$rawdatafile$name)

            # 重新加载数据并生成新的rv$merged_data后，将指定的rv元素设置为NULL
            rv$total_prediction <- NULL
            rv$plot_time_data <- NULL
            rv$summary_by_event <- NULL
            rv$overall_summary <- NULL

            # 更新进度消息（成功）
            shinyjs::html(ns("progress_upload"), "Data merged successfully!")
          } else {
            shinyjs::html(ns("progress_upload"), "Error: Data could not be merged.")
          }
        },
        error = function(e) {
          shinyjs::html(ns("progress_upload"), "Import failed. Check the data and event sheets.")
          showNotification(conditionMessage(e), type = "error", duration = 15)
        },
        finally = {
          # 清理临时文件
          if (file.exists(temp_file)) {
            unlink(temp_file)
          }
        })

        # 完成进度
        incProgress(0.2, detail = "Complete!")
      })

      # 短暂延迟后隐藏进度消息
      shinyjs::delay(2000, shinyjs::hide(ns("progress_upload")))
    })

    # 修改内置数据处理函数，添加进度条
    observeEvent(input$loadBuiltinEvents, {
      req(input$samplecountry, input$builtinsheetname, input$builtineventsheetname)

      # 显示进度消息
      shinyjs::html(ns("progress_builtin"), "Loading built-in data, please wait...")
      shinyjs::show(ns("progress_builtin"))

      # 修改国家名称处理方式，参考data_tab.R的处理方法
      file_path <- builtin_mortality_path(input$samplecountry)

      # 使用withProgress显示进度条
      withProgress(message = "Loading built-in data...", value = 0, {
        # 检查文件是否存在
        if (file.exists(file_path)) {
          # 读取原始数据
          incProgress(0.2, detail = "Reading mortality data...")
          raw_data <- openxlsx::read.xlsx(file_path, sheet = input$builtinsheetname, colNames = FALSE)
          data$acm_rawdata <- raw_data

          # 处理死亡率数据
          incProgress(0.4, detail = "Processing mortality data...")
          data$acm_data <- read_mortality_sheet(file_path, input$builtinsheetname)
          data$source_note <- mortality_source_note(file_path)
          if (all(data$acm_data$ISO3 == "UNK")) {
            data$acm_data$COUNTRY <- input$samplecountry
            data$acm_data$ISO3 <- unname(c(Australia = "AUS", Japan = "JPN", `Republic of Korea` = "KOR",
                                          `New Zealand` = "NZL", Philippines = "PHL")[[input$samplecountry]])
          }

          # 加载事件数据
          incProgress(0.6, detail = "Loading events data...")
          data$event_data <- loadEventsData(file_path, input$builtineventsheetname)

          # 合并数据
          incProgress(0.8, detail = "Merging data...")
          if (!is.null(data$acm_data) && !is.null(data$event_data)) {
            data$merged_data <- mergeEventsData(data$acm_data, data$event_data)
            data$data_description <- paste("Built-in", input$samplecountry, "data")

            # 重新加载数据并生成新的rv$merged_data后，将指定的rv元素设置为NULL
            rv$total_prediction <- NULL
            rv$plot_time_data <- NULL
            rv$summary_by_event <- NULL
            rv$overall_summary <- NULL

            # 更新进度消息（成功）
            shinyjs::html(ns("progress_builtin"), "Built-in data loaded successfully!")
          } else {
            shinyjs::html(ns("progress_builtin"), "Error: Data could not be loaded.")
          }
        } else {
          shinyjs::html(ns("progress_builtin"), "Error: File not found.")
        }

        # 完成进度
        incProgress(0.2, detail = "Complete!")
      })

      # 短暂延迟后隐藏进度消息
      shinyjs::delay(2000, shinyjs::hide(ns("progress_builtin")))
    })

    # 表格输出
    output$ACM_table <- renderDT({
      req(selected_mortality())
      datatable(selected_mortality(),
                options = list(
                  pageLength = 10,
                  scrollX = TRUE,
                  autoWidth = FALSE,  # 修改为FALSE以防止自动调整宽度
                  scrollCollapse = TRUE,
                  dom = 'Blfrtip',
                  buttons = list(
                    list(extend = 'copy', text = 'Copy')
                  ),
                  columnDefs = list(  # 添加列定义以确保对齐
                    list(className = 'dt-center', targets = '_all')
                  )
                ),
                rownames = FALSE,
                extensions = 'Buttons')
    })

    output$raw_mortality_table <- renderDT({
      if (is.null(data$acm_rawdata)) {
        datatable(data.frame(Message = "No mortality data loaded yet"), options = list(dom = "t"), rownames = FALSE)
      } else {
        datatable(data$acm_rawdata,
                  options = list(
                    pageLength = 10,
                    scrollX = TRUE,
                    autoWidth = FALSE,  # 修改为FALSE
                    scrollCollapse = TRUE,
                    dom = 'Blfrtip',
                    buttons = list(
                      list(extend = 'copy', text = 'Copy')
                    ),
                    columnDefs = list(  # 添加列定义
                      list(className = 'dt-center', targets = '_all')
                    )
                  ),
                  rownames = FALSE,
                  extensions = 'Buttons')
      }
    })

    output$events_table <- renderDT({
      if (is.null(data$event_data)) {
        datatable(data.frame(Message = "No events data loaded yet"), options = list(dom = "t"), rownames = FALSE)
      } else {
        datatable(data$event_data,
                  options = list(
                    pageLength = 10,
                    scrollX = TRUE,
                    autoWidth = FALSE,  # 修改为FALSE
                    scrollCollapse = TRUE,
                    dom = 'Blfrtip',
                    buttons = list(
                      list(extend = 'copy', text = 'Copy')
                    ),
                    columnDefs = list(  # 添加列定义
                      list(className = 'dt-center', targets = '_all')
                    )
                  ),
                  rownames = FALSE,
                  extensions = 'Buttons')
      }
    })

    # 添加下载处理器 - 修改为使用Excel格式
    output$downloadMergedData <- downloadHandler(
      filename = function() {
        paste("Merged_Data_", format(Sys.Date(), "%Y-%m-%d"), ".xlsx", sep = "")
      },
      content = function(file) {
        req(selected_mortality())
        openxlsx::write.xlsx(selected_mortality(), file, rowNames = FALSE)
      }
    )

    output$downloadRawData <- downloadHandler(
      filename = function() {
        paste("Raw_Mortality_Data_", format(Sys.Date(), "%Y-%m-%d"), ".xlsx", sep = "")
      },
      content = function(file) {
        req(data$acm_rawdata)
        openxlsx::write.xlsx(data$acm_rawdata, file, rowNames = FALSE)
      }
    )

    output$downloadEventsData <- downloadHandler(
      filename = function() {
        paste("Events_Data_", format(Sys.Date(), "%Y-%m-%d"), ".xlsx", sep = "")
      },
      content = function(file) {
        req(data$event_data)
        openxlsx::write.xlsx(data$event_data, file, rowNames = FALSE)
      }
    )

    # 数据摘要输出
    output$ACMsum <- renderPrint({
      if (is.null(data$merged_data)) {
        cat("No data loaded yet.\n")
      } else {
        selected <- selected_mortality()
        cat("Country:", selected$COUNTRY[1], "\nCause:", selected$CAUSE[1], "\n")
        cat("Years:", min(selected$YEAR), "-", max(selected$YEAR), "\n\n")
        print(selected |> group_by(AREA, SEX, AGE_GROUP) |> summarise(
          Periods = n(), Missing = sum(is.na(NO_DEATHS)),
          Recorded_deaths = if (all(is.na(NO_DEATHS))) NA_real_ else sum(NO_DEATHS, na.rm = TRUE),
          .groups = "drop"))
      }
    })

    # 下载处理程序
    output$download_templates <- downloadHandler(
      filename = function() {
        if (identical(input$template_country, "Cause-specific monthly template")) return("Cause-specific monthly template.xlsx")
        paste0(c(
          "Australia (empty template).xlsx", "Philippines (empty template).xlsx", "French Polynesia (empty template).xlsx",
          "Data Entry Template - monthly.xlsx", "Data Entry Template - weekly.xlsx",
          "Australia_built_in_data.xlsx", "Japan_built_in_data.xlsx",
          "Republic_of_Korea_built_in_data.xlsx", "New_Zealand_built_in_data.xlsx",
          "Philippines_built_in_data.xlsx"
        )[
          match(input$template_country, c(
            "Australia (empty template)", "Philippines (empty template)", "French Polynesia (empty template)",
            "Generic Monthly template", "Generic Weekly template",
            "Australia (filled up to August 2020)", "Japan (filled up to August 2020)",
            "Republic of Korea (filled up to August 2020)", "New Zealand (filled up to August 2020)",
            "Philippines (filled up to August 2020)"
          ))
        ])
      },
      content = function(file) {
        if (identical(input$template_country, "Cause-specific monthly template")) {
          file.copy("XLSX/Cause-specific monthly template.xlsx", file)
          return(invisible(NULL))
        }
        file.copy(
          from = paste0(
            "./XLSX/",
            c(
              "Australia (empty template).xlsx", "Philippines (empty template).xlsx", "French Polynesia (empty template).xlsx",
              "Data Entry Template - monthly.xlsx", "Data Entry Template - weekly.xlsx",
              "Australia_built_in_data.xlsx", "Japan_built_in_data.xlsx",
              "Republic_of_Korea_built_in_data.xlsx", "New_Zealand_built_in_data.xlsx",
              "Philippines_built_in_data.xlsx"
            )[
              match(input$template_country, c(
                "Australia (empty template)", "Philippines (empty template)", "French Polynesia (empty template)",
                "Generic Monthly template", "Generic Weekly template",
                "Australia (filled up to August 2020)", "Japan (filled up to August 2020)",
                "Republic of Korea (filled up to August 2020)", "New Zealand (filled up to August 2020)",
                "Philippines (filled up to August 2020)"
              ))
            ]
          ),
          to = file
        )
      }
    )

  }) # End moduleServer
} # Add this closing bracket for the data_process_module_server function
