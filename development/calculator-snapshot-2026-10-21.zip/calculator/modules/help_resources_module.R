# --- 1. 加载必要的库 ---
# 假设主要库已在app.R中加载
# library(shiny)

# --- 2. 定义模块UI ---
help_resources_module_ui <- function(id) {
  ns <- NS(id)
  li  <- tags$li
  ol  <- tags$ol
  pre <- tags$pre
  
  sidebarLayout(
    position = 'right',
    sidebarPanel(
      h5(tags$u('Resources')),
      div(title = "Wiki page for the calculator",
          a("About WPRO all-cause-of-mortality and excess death calculator",
            href = "https://github.com/WorldHealthOrganization/ACMCalculator/wiki",
            target = "_blank")),
      div(title="WPRO all-cause mortality dashboard",
          a("WPRO all-cause mortality dashboard",
            href="https://lynx.wpro.who.int/viz/allcausedeath.asp",
            target="_blank")
      ),
      div(title=paste("Information on the methodology used",
                      "in the calculator"),
          a("About the methodology used in the tool.",
            href = "https://github.com/WorldHealthOrganization/ACMCalculator/wiki/Methodology-used-in-ACMCalculator/", target = "_blank")
      ),
      br(),
      div(a("WPRO all-cause-of-mortality and excess death calculator on GitHub", href="https://github.com/WorldHealthOrganization/ACMCalculator",
            target="_blank")),
      div(a("Shiny: a web application framework for R", href="http://shiny.rstudio.com/",
            target="_blank"))
    ),
    mainPanel(
      
      ## ---------- 标题 ----------
      h3("Help with the WPRO All-Cause-of-Mortality & Excess Death Calculator"),
      p(
        "This app is maintained on GitHub. To request new features or report a bug, ",
        "please open an issue in the ",
        a("repository",
          href = "https://github.com/WorldHealthOrganization/ACMCalculator",
          target = "_blank"),
        " or email us at ",
        a(icon("envelope"), " dings@who.int",
          href = "mailto:dings@who.int"),
        ", ",
        a(icon("envelope"), " sedait@who.int",
          href = "mailto:sedait@who.int"), "."
      ),
      
      ## ---------- 安装指南（折叠） ----------
      tags$details(
        tags$summary(tags$b("📥 How to install the app offline (click to expand)")),
        p("Running the app locally keeps your data on your machine and works without internet."),
        ol(
          li("Open ", strong("RGui"), " (⚠ not RStudio)."),
          li("In the ", strong("R Console"), " run:"),
          tags$pre('source("https://faculty.stat.ucla.edu/handcock/ACMCalculator.R")'),
          li("Wait until R closes. In your Documents folder you will see ",
             strong("ACMCalculator"), "."),
          li("Double-click it to launch the app in your browser. If it doesn’t open, ",
             "close the browser and double-click again."),
          li("Next time simply double-click ", strong("ACMCalculator"), " to start the app.")
        )
      ),
      
      hr(),   ## 分割线
      
      ## ---------- 用户指南（折叠） ----------
      tags$details(
        tags$summary(tags$b("📖 ACM Excess Mortality Model User Guide (click to expand)")),
        
        h4("1  Introduction"),
        p("This guide explains how to use the Historical Average, Negative-Binomial, ",
          "and other models to estimate excess mortality correctly."),
        
        h4("2  Basic Model Assumptions"),
        tags$ul(
          li(strong("Event impact:"), " major health events (e.g. COVID-19) may raise deaths."),
          li(strong("Intervention impact:"), " control measures may reduce deaths."),
          li(strong("Baseline prediction:"), " models learn from pre-event ‘normal’ data ",
             "to predict expected deaths during the event.")
        ),
        
        h4("3  Key Points & Tips"),
        
        ## --- 3.1 事件期一致性 ---
        h5("3.1  Data Input & Event-Period Consistency"),
        p("Define the event period precisely; training data should exclude that period ",
          "and any abnormal post-event weeks unless they truly represent a new baseline."),
        div(class = "alert alert-info",
            "Tip: mis-setting the event period (e.g. including data to Dec 2023 ",
            "when analysing up to Aug 2023) will under-estimate excess mortality."),
        
        ## 用 <ul> / <ol> 合法嵌套
        tags$ul(
          li(strong("Checklist before running:"), 
             tags$ul(
               li("Event start & end dates set?"),
               li("Training data excludes event & unstable post-event weeks?"),
               li("Preview the automatic ", code("event_index"), " column in the upload preview.")
             )
          )
        ),
        
        ## --- 3.2 事件期定义差异 ---
        h5("3.2  Why different event dates give different results"),
        tags$ul(
          li("Changing dates changes the training set → different expected deaths."),
          li("Keep the definition consistent across all analyses unless justified.")
        ),
        
        ## --- 3.3 是否包含后事件期 ---
        h5("3.3  Including post-event data in training"),
        tags$ul(
          li("May distort baseline if trends shifted after the event."),
          li("Generally avoid unless mortality clearly returned to normal.")
        ),
        
        h4("4  Conclusion"),
        p("Careful data preparation and correct event-period definition are key to reliable ",
          "excess-mortality estimates. For details see the methodology page or contact us.")
      )
    )
  )
}

# --- 3. 定义模块服务器 ---
help_resources_module_server <- function(id, rv) {
  moduleServer(id, function(input, output, session) {
    # 邮件按钮的观察器
    observeEvent(input$email1, {
      # 这里不需要做任何事情，因为邮件链接是通过href属性处理的
    })
    
    observeEvent(input$email2, {
      # 这里不需要做任何事情，因为邮件链接是通过href属性处理的
    })
  })
}