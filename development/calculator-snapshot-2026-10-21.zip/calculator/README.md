# Cause-specific calculator development snapshot

This directory preserves the standalone calculator developed in the EM workspace on 21 October 2026.
It is a backup and comparison snapshot. It has not been integrated into the package application in `inst/app/`.
Installing this branch as an R package and calling `exmort::run_app()` still launches the existing package application.

To run this snapshot, open `calculator.Rproj` in RStudio and run `source("scripts/preview_cause_calculator.R")`.
See [CAUSE_SPECIFIC.md](CAUSE_SPECIFIC.md) for data selection, source details, modelling assumptions and validation.

## Changes preserved here

- Country and cause selection after workbook import, with stale results cleared when the selection changes.
- Separate monthly Historical Average and Negative Binomial cause baselines, preserving fractional expected counts and distinguishing missing counts from zeros.
- Approximate monthly and aggregate uncertainty, P-scores, plots and reports carrying the selected country and cause.
- Official Australian monthly cause examples from 2015 and Philippine examples for 2019-2024, plus an input template.
- Preparation scripts, functional tests, and the public source inputs used to reproduce the bundled examples.

The Philippine example compares 2024 with 2019-2023. Its history includes pandemic years and does not provide a no-pandemic counterfactual.
The source cache preserves the published snapshot rather than refreshing it. Its 2019 Philippine input is the saved official PDF web-reader text; 2020-2022 use official spreadsheets.

## Differences from the package application

The package application already includes GAM, Karlinsky-Kobak and Best Fit features, package-local module sourcing, upload validators, normalized template filenames and a separate report template.
The standalone snapshot comes from an earlier application structure. Its 21 shared R files differ in text; some differences are comments or cleanup, while others change behaviour.
Do not replace `inst/app/` wholesale with this snapshot. A later integration should port the cause feature while retaining the package improvements.

Validation on the source workspace: the cause-specific test runner reached `CAUSE_TESTS_COMPLETE` with no failed assertions. The existing Windows R process-exit anomaly remains.
A browser check confirmed the Philippine ischaemic-heart-disease example produces model predictions and a chart. This is not a CRAN release or a claim that all sparse causes are estimable.

The snapshot excludes local settings, deployment metadata, session history, generated reports, screenshots and redundant backup files.
It retains the existing package's GPL-3 licence and WHO WPRO attribution.
